// event listener for form submission
document.getElementById('reservationForm').addEventListener('submit', function(event) {
    event.preventDefault(); // prevents page reload
    
    // set form data
    const fullName = document.getElementById('fullName').value.trim();
    const email = document.getElementById('email').value.trim();
    const location = document.getElementById('location').value;
    const duration = document.getElementById('duration').value;
    const pickupTime = document.getElementById('pickupTime').value;
    
    // validates if field input is correct
    if (fullName.length < 2) {
        alert('Please enter a valid name');
        return;
    }

    if (/\d/.test(fullName)) {
        alert('Name cannot contain numbers');
        return;
    }
    
    if (!validateEmail(email)) {
        alert('Please enter a valid email address');
        return;
    }
    
    if (location === '') {
        alert('Please select a location');
        return;
    }
    
    if (duration < 1 || duration > 24) {
        alert('Duration must be between 1 and 24 hours');
        return;
    }
    
    // checks if pickup time is in the future
    const selectedTime = new Date(pickupTime);
    const now = new Date();
    if (selectedTime < now) {
        alert('Pickup time must be in the future');
        return;
    }
    
    // creates and displays a confirmation message
    const confirmationDiv = document.getElementById('confirmationMessage');
    confirmationDiv.innerHTML = `
        <div class="confirmation-card">
            <h3>✅ Reservation Confirmed!</h3>
            <p><strong>Name:</strong> ${fullName}</p>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Location:</strong> ${getLocationName(location)}</p>
            <p><strong>Duration:</strong> ${duration} hours</p>
            <p><strong>Pickup Time:</strong> ${formatDateTime(pickupTime)}</p>
            <p>A confirmation email has been sent to ${email}</p>
        </div>
    `;
    confirmationDiv.style.display = 'block'; //shows the new message
    
    // hides the form
    document.getElementById('reservationForm').style.display = 'none';

    //creates a reserve another scooter button
    const resetButton = document.createElement('button');
    resetButton.textContent = 'Reserve Another Scooter';
    resetButton.className = 'cta-button';
    resetButton.style.marginTop = '1.5rem';
    resetButton.onclick = function() {
        document.getElementById('reservationForm').reset();
        document.getElementById('reservationForm').style.display = 'block';
        confirmationDiv.style.display = 'none';
    };
    confirmationDiv.querySelector('.confirmation-card').appendChild(resetButton);
});



// email validation function
function validateEmail(email) {
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailPattern.test(email);
}

// helper function to get location name
function getLocationName(locationCode) {
    const locations = {
        'sinatra': 'Sinatra Drive',
        'river': 'River Terrace',
        'washington': 'Washington Street'
    };
    return locations[locationCode] || locationCode;
}

// formats date
function formatDateTime(dateTimeString) {
    const date = new Date(dateTimeString);
    return date.toLocaleString();
}